<!DOCTYPE html>
<html>
<head>
    <title> PHP - MySQL Lesson </title>
</head>

<body>

<form action="register.php" method="post">

<table width="300" border="0" cellspacing="1" cellpadding="1">
  <tr>
    <td>First Name:</td>
    <td> <input type="text" name="fname"></td>
  </tr>
  <tr>
    <td>Last Name:</td>
    <td><input type="text" name="lname"></td>
  </tr>
  <tr>
    <td>E-mail:</td>
    <td><input type="text" name="email"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit"></td>
  </tr>
</table>

</form>

</body>

</html>