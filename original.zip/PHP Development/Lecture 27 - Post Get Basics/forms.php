<!DOCTYPE HTML>
<html> 
<body>

<form action="send.php" method="GET">
	First Name: <input type="text" name="fname"><br>
	E-mail: <input type="text" name="email"><br>
	<input type="submit">
</form>

</body>
</html>