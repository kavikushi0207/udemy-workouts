<!DOCTYPE HTML>
<html> 
<body>

First Name: <?php echo $_GET["fname"]; ?><br>
Email: <?php echo $_GET["email"]; ?>

</body>
</html>